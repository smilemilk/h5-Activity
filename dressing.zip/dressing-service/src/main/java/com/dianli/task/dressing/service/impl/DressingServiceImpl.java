package com.dianli.task.dressing.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.dianli.task.dressing.dao.bean.MaterialDo;
import com.dianli.task.dressing.dao.bean.MaterialDoExample;
import com.dianli.task.dressing.dao.bean.OpLogDo;
import com.dianli.task.dressing.dao.bean.UserSignUpDo;
import com.dianli.task.dressing.dao.bean.UserSignUpDoExample;
import com.dianli.task.dressing.dao.bean.UserSignUpDoExample.Criteria;
import com.dianli.task.dressing.dao.mapper.MaterialDoMapper;
import com.dianli.task.dressing.dao.mapper.OpLogDoMapper;
import com.dianli.task.dressing.dao.mapper.UserSignUpDoMapper;
import com.dianli.task.dressing.domain.base.BaseResult;
import com.dianli.task.dressing.domain.base.BaseVo;
import com.dianli.task.dressing.domain.base.DelBaseInDto;
import com.dianli.task.dressing.domain.dto.AddMaterialInDto;
import com.dianli.task.dressing.domain.dto.QueryMaterialInDto;
import com.dianli.task.dressing.domain.dto.SignUpInDto;
import com.dianli.task.dressing.enumerate.OpTypeEnum;
import com.dianli.task.dressing.service.DressingService;
import javafx.scene.paint.Material;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

/**
 * @author Task
 */
@Service
public class DressingServiceImpl implements DressingService {

    @Resource
    private UserSignUpDoMapper userSignUpDoMapper;

    @Resource
    private MaterialDoMapper materialDoMapper;

    @Resource
    private OpLogDoMapper opLogDoMapper;

    @Override
    public BaseResult signUp(SignUpInDto baseVo) {
        //检查是否已经报名
        UserSignUpDoExample example = new UserSignUpDoExample();
        Criteria criteria = example.createCriteria();
        criteria.andOpenIdEqualTo(baseVo.getOpenId());
        criteria.andDelFlagEqualTo(0);
        int num = userSignUpDoMapper.countByExample(example);
        if(num > 0){
            return BaseResult.buildFaild("您已经报名过，不能重复报名！");
        }

        //执行报名操作
        UserSignUpDo userSignUpDo = new UserSignUpDo();
        BeanUtils.copyProperties(baseVo,userSignUpDo);
        userSignUpDo.setCreateTime(new Date());
        userSignUpDo.setDelFlag(0);
        num = userSignUpDoMapper.insertSelective(userSignUpDo);
        if(num == 0){
            return BaseResult.buildFaild("报名失败，请稍后重试！");
        }
        return BaseResult.buildSuccess(userSignUpDo);
    }

    @Override
    public BaseResult addMaterial(AddMaterialInDto baseVo) {
        //检查重复性
        MaterialDoExample example = new MaterialDoExample();
        MaterialDoExample.Criteria criteria = example.createCriteria();
        criteria.andDelFlagEqualTo(0);
        criteria.andOpenIdEqualTo(baseVo.getOpenId());
        int num = materialDoMapper.countByExample(example);
        if(num == 1){
            //此处处理是幂等操作，避免重复点击导致多次插入
            return BaseResult.buildSuccess(num);
        }

        //执行插入操作
        MaterialDo materialDo = new MaterialDo();
        BeanUtils.copyProperties(baseVo,materialDo);
        materialDo.setCreateTime(new Date());
        materialDo.setDelFlag(0);
        num = materialDoMapper.insertSelective(materialDo);
        if(num == 0){
            return BaseResult.buildFaild("选取失败，请重试！");
        }
        return BaseResult.buildSuccess(materialDo);
    }

    @Override
    public BaseResult queryMaterial(QueryMaterialInDto baseVo) {
        //构建查询条件
        MaterialDoExample example = new MaterialDoExample();
        MaterialDoExample.Criteria criteria = example.createCriteria();

        criteria.andDelFlagEqualTo(0);
        criteria.andOpenIdEqualTo(baseVo.getOpenId());

        if(null != baseVo.getMaterialType()){
            criteria.andMaterialTypeEqualTo(baseVo.getMaterialType());
        }
        if(null != baseVo.getFinalChoice()){
            criteria.andFinalChoiceEqualTo(baseVo.getFinalChoice());
        }

        List<MaterialDo> materialDoList = materialDoMapper.selectByExample(example);

        //执行结果返回
        return BaseResult.buildSuccess(materialDoList);
    }

    @Override
    public BaseResult delMaterial(DelBaseInDto baseVo) {
        MaterialDo materialDo = new MaterialDo();
        materialDo.setId(baseVo.getId());
        materialDo.setDelFlag(1);
        materialDo.setModifyTime(new Date());
        int num = materialDoMapper.updateByPrimaryKeySelective(materialDo);
        if(num == 0){
            return BaseResult.buildFaild("资源删除失败！");
        }
        return BaseResult.buildSuccess(materialDo);
    }

    @Override
    public BaseResult opIndex(BaseVo baseVo) {
        OpLogDo opLogDo = new OpLogDo();
        opLogDo.setCreateTime(new Date());
        opLogDo.setDelFlag(0);
        opLogDo.setOpenId(baseVo.getOpenId());
        opLogDo.setOpType(OpTypeEnum.INDEX.getKey());
        int num = opLogDoMapper.insertSelective(opLogDo);
        if(num == 0){
            return BaseResult.buildFaild("设置操作日志失败！");
        }
        return BaseResult.buildSuccess(opLogDo);
    }

    @Override
    public BaseResult opCreate(BaseVo baseVo) {
        OpLogDo opLogDo = new OpLogDo();
        opLogDo.setCreateTime(new Date());
        opLogDo.setDelFlag(0);
        opLogDo.setOpenId(baseVo.getOpenId());
        opLogDo.setOpType(OpTypeEnum.CREATE.getKey());
        int num = opLogDoMapper.insertSelective(opLogDo);
        if(num == 0){
            return BaseResult.buildFaild("设置操作日志失败！");
        }
        return BaseResult.buildSuccess(opLogDo);
    }

    @Override
    public BaseResult opScan(BaseVo baseVo) {
        OpLogDo opLogDo = new OpLogDo();
        opLogDo.setCreateTime(new Date());
        opLogDo.setDelFlag(0);
        opLogDo.setOpenId(baseVo.getOpenId());
        opLogDo.setOpType(OpTypeEnum.SACN.getKey());
        int num = opLogDoMapper.insertSelective(opLogDo);
        if(num == 0){
            return BaseResult.buildFaild("设置操作日志失败！");
        }
        return BaseResult.buildSuccess(opLogDo);
    }
}
