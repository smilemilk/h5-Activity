package com.dianli.task.dressing.config;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.dianli.task.dressing.dao.bean.AwardConfigDo;

/**
 * @author Task
 */
public class CommonConstance {

    /**
     * 保存openId的sessionKey
     */
    public static final String OPEN_ID_SESSION_KEY = "OPEN_ID_SESSION_KEY";

    /**
     * 保存微信昵称的sessionKey
     */
    public static final String WECHART_NICK_SESSION_KEY = "WECHART_NICK_SESSION_KEY";

    /**
     * 缓存抽奖规则数据
     * awardKey awardConfig
     */
    public static final Map<Integer,AwardConfigDo> AWARD_CONFIG_DO_MAP= new HashMap<>();

    /**
     * 缓存抽奖截止到key的映射
     * (int)rate*100 awardKey
     */
    public static final Map<Integer,Integer> AWARD_CONFIG_KV_MAP= new TreeMap<>();

    /**
     * 不中奖的奖项
     */
    public static Integer AWARD_CONFIG_NO_KEY;

    /**
     * 获取基础登录信息
     */
    public static final String SNSAPI_BASE = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=%s&redirect_uri=%s&response_type=code&scope=snsapi_base&state=STATE#wechat_redirect";

    /**
     * 获取详细登录信息
     */
    public static final String SNSAPI_USER_INFO = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=%s&redirect_uri=%s&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";

    /**
     * 获取授权信息
     */
    public static final String ACCESS_TOKEN = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=%s&secret=%s&code=%s&grant_type=authorization_code";

    /**
     * 获取用户信息
     */
    public static final String USER_INFO = "https://api.weixin.qq.com/sns/userinfo?access_token=%s&openid=%s&lang=zh_CN";

    /**
     * 中奖信息导出表头
     */
    public static final String[] AWARD_ROW_TH_CELLS = {"中奖时间","微信昵称","openId","中奖奖品名称","中奖等级","领奖人姓名","领奖人手机号","领奖人收货地址"};

    /**
     * 中奖信息导出表字段
     */
    public static final String[] AWARD_ROW_TD_CELLS = {"awardTime","wechatNick","openId","award","awardLevel","name","phone","address"};

    /**
     * 导出报名人信息表头
     */
    public static final String[] SIGNUP_ROW_TH_CELLS = {"报名时间","微信昵称","openId","姓名","手机号","是否携带儿童","儿童年龄","预计到场人数"};

    /**
     * 导出报名人信息字段
     */
    public static final String[] SIGNUP_ROW_TD_CELLS = {"createTime","wechatNick","openId","name","phone","carryChildren","childrenAge","turnoutNum"};
}
