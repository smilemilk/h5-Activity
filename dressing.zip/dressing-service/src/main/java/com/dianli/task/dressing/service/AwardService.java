package com.dianli.task.dressing.service;

import com.dianli.task.dressing.domain.base.BaseResult;
import com.dianli.task.dressing.domain.base.BaseVo;
import com.dianli.task.dressing.domain.dto.AddAwardInfoInDto;
import com.dianli.task.dressing.domain.dto.QueryAwardInDto;

public interface AwardService {
    BaseResult queryAwardTimes(BaseVo baseVo);

    BaseResult opShare(BaseVo baseVo);

    BaseResult opAward(BaseVo baseVo);

    BaseResult loadAwardConfig();

    BaseResult addAwardInfo(AddAwardInfoInDto baseVo);

    BaseResult queryAwardInfo(QueryAwardInDto queryAwardInDto);
}
