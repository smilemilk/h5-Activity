package com.dianli.task.dressing.service.impl;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import com.dianli.task.dressing.config.CommonConstance;
import com.dianli.task.dressing.dao.bean.UserDo;
import com.dianli.task.dressing.dao.bean.UserDoExample;
import com.dianli.task.dressing.dao.bean.UserDoExample.Criteria;
import com.dianli.task.dressing.dao.mapper.UserDoMapper;
import com.dianli.task.dressing.domain.base.BaseResult;
import com.dianli.task.dressing.domain.base.BaseVo;
import com.dianli.task.dressing.domain.dto.AccessOutDto;
import com.dianli.task.dressing.domain.dto.AuthInDto;
import com.dianli.task.dressing.domain.dto.UserInfoInDto;
import com.dianli.task.dressing.service.AuthService;
import com.dianli.task.dressing.service.DressingService;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

/**
 * @author Task
 */
@Service
public class AuthServiceImpl implements AuthService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthService.class);

    @Value("${weixin.appid}")
    private String appId;

    @Value("${weixin.redirectUri}")
    private String redirectUri;

    @Value("${weixin.appSecret}")
    private String appSecret;

    /**
     * 首页地址
     */
    private String index = "/index.htm";
    /**
     * 基础信息回调地址
     */
    private String baseCallback = "/baseCallback";
    /**
     * 用户信息授权回调地址
     */
    private String infoCallback = "/infoCallback";

    @Resource
    private UserDoMapper userDoMapper;

    @Resource
    private DressingService dressingService;

    @Override
    public String index(BaseVo vo) {
        //已存在用户信息，直接转到首页
        if (!StringUtils.isEmpty(vo.getOpenId())) {
            dressingService.opIndex(vo);
            return redirectUri + index;
        }

        //未登录，引导进入登录
        return String.format(CommonConstance.SNSAPI_BASE, appId, redirectUri + baseCallback);
    }

    /**
     * 微信回调信息接口
     *
     * @param inDto
     * @return
     */
    @Override
    public BaseResult baseCallback(AuthInDto inDto, HttpServletResponse resp) throws UnirestException, IOException {
        HttpResponse<String> response = Unirest.post(
            String.format(CommonConstance.ACCESS_TOKEN, appId, appSecret, inDto.getCode())).asString();

        LOGGER.info("ACCESS_TOKEN返回：{}", response.getBody());

        AccessOutDto outDto = JSON.parseObject(response.getBody(), AccessOutDto.class);
        if (null == outDto.getErrcode()) {
            //判断用户是否存在，已存在的用户无需再获取详情
            UserDoExample example = new UserDoExample();
            Criteria criteria = example.createCriteria();
            criteria.andDelFlagEqualTo(0);
            criteria.andOpenIdEqualTo(outDto.getOpenid());
            List<UserDo> userDoList = userDoMapper.selectByExample(example);
            //不存在用户，引导进入授权页面,存在添加session
            if (CollectionUtils.isEmpty(userDoList)) {
                resp.sendRedirect(String.format(CommonConstance.SNSAPI_USER_INFO, appId, redirectUri + infoCallback));
            } else {
                return BaseResult.buildSuccess(userDoList.get(0));
            }
        }
        return BaseResult.buildFaild(outDto.getErrmsg());
    }

    @Override
    public BaseResult infoCallback(AuthInDto inDto) throws UnirestException {
        HttpResponse<String> response = Unirest.post(
            String.format(CommonConstance.ACCESS_TOKEN, appId, appSecret, inDto.getCode())).asString();
        LOGGER.info("获取用户信息接口返回：{}", response.getBody());

        AccessOutDto outDto = JSON.parseObject(response.getBody(), AccessOutDto.class);
        if (null == outDto.getErrcode()) {
            //请求授权登录成功，拉取用户详情并保存
            response = Unirest.post(
                String.format(CommonConstance.USER_INFO, outDto.getAccess_token(), outDto.getOpenid())).asString();

            LOGGER.info("用户详情返回：{}",response.getBody());

            UserInfoInDto userInfo = JSON.parseObject(response.getBody(), UserInfoInDto.class);
            if (null == userInfo.getErrcode()) {
                //构建插入对象
                UserDo userDo = new UserDo();
                userDo.setAccessToken(outDto.getAccess_token());
                userDo.setCity(userInfo.getCity());
                userDo.setCountry(userInfo.getCountry());
                userDo.setCreateTime(new Date());
                userDo.setDelFlag(0);
                userDo.setExpiresIn(outDto.getExpires_in());
                userDo.setHeadingImgUrl(userInfo.getHeadingimgurl());
                userDo.setUnionid(userInfo.getUnionid());
                userDo.setOpenId(userInfo.getOpenid());
                userDo.setRefreshToken(outDto.getRefresh_token());
                userDo.setSex(userInfo.getSex());
                userDo.setProvince(userInfo.getProvince());
                userDo.setNickName(userInfo.getNickname());
                userDoMapper.insertSelective(userDo);

                //添加新用户访问记录
                BaseVo baseVo = new BaseVo();
                baseVo.setOpenId(outDto.getOpenid());
                baseVo.setWechatNick(userInfo.getNickname());
                dressingService.opIndex(baseVo);

                return BaseResult.buildSuccess(userDo);
            }

            return BaseResult.buildFaild(userInfo.getErrmsg());
        }

        return BaseResult.buildFaild(outDto.getErrmsg());
    }
}
