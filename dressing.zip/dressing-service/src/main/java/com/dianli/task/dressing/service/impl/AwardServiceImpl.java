package com.dianli.task.dressing.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.dianli.task.dressing.config.CommonConstance;
import com.dianli.task.dressing.dao.bean.AwardConfigDo;
import com.dianli.task.dressing.dao.bean.AwardConfigDoExample;
import com.dianli.task.dressing.dao.bean.AwardUserDo;
import com.dianli.task.dressing.dao.bean.AwardUserDoExample;
import com.dianli.task.dressing.dao.bean.AwardUserDoExample.Criteria;
import com.dianli.task.dressing.dao.bean.OpLogDo;
import com.dianli.task.dressing.dao.mapper.AwardConfigDoMapper;
import com.dianli.task.dressing.dao.mapper.AwardUserDoMapper;
import com.dianli.task.dressing.dao.mapper.OpLogDoMapper;
import com.dianli.task.dressing.domain.base.BaseResult;
import com.dianli.task.dressing.domain.base.BaseVo;
import com.dianli.task.dressing.domain.dto.AddAwardInfoInDto;
import com.dianli.task.dressing.domain.dto.QueryAwardInDto;
import com.dianli.task.dressing.enumerate.OpTypeEnum;
import com.dianli.task.dressing.service.AwardService;
import org.apache.ibatis.transaction.Transaction;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

@Service
public class AwardServiceImpl implements AwardService {

    @Resource
    private AwardUserDoMapper awardUserDoMapper;

    @Resource
    private AwardConfigDoMapper awardConfigDoMapper;

    @Resource
    private OpLogDoMapper opLogDoMapper;

    @Override
    public BaseResult queryAwardTimes(BaseVo baseVo) {
        BaseResult<AwardUserDo> baseResult = queryAwardInfo((QueryAwardInDto)baseVo);
        if(!baseResult.isSuccess()){
            return baseResult;
        }
        return BaseResult.buildSuccess(baseResult.getData().getEnableAwardTimes());
    }

    @Override
    public BaseResult opShare(BaseVo baseVo) {
        BaseResult<AwardUserDo> baseResult = queryAwardInfo((QueryAwardInDto)baseVo);
        if(!baseResult.isSuccess()){
            return baseResult;
        }

        AwardUserDo awardUserDo = baseResult.getData();

        AwardUserDo upd = new AwardUserDo();
        upd.setEnableAwardTimes(awardUserDo.getEnableAwardTimes()+1);
        upd.setId(awardUserDo.getId());
        int num =awardUserDoMapper.updateByPrimaryKeySelective(upd);
        if(num == 0){
            return BaseResult.buildFaild("更新可抽奖次数失败！");
        }

        //添加分享记录
        OpLogDo opLogDo = new OpLogDo();
        opLogDo.setCreateTime(new Date());
        opLogDo.setDelFlag(0);
        opLogDo.setOpenId(baseVo.getOpenId());
        opLogDo.setOpType(OpTypeEnum.SHARE.getKey());
        num = opLogDoMapper.insertSelective(opLogDo);
        if(num == 0){
            //确保原子性操作，不成就回滚
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return BaseResult.buildFaild("设置操作日志失败！");
        }
        return BaseResult.buildSuccess(opLogDo);
    }

    @Override
    public BaseResult opAward(BaseVo baseVo) {
        //检查抽奖次数是否大于1
        AwardUserDo awardUserDo = queryUserByOpenId(baseVo.getOpenId());
        if(null == awardUserDo){
            return BaseResult.buildFaild("获取人员信息失败！");
        }

        if(null == awardUserDo.getEnableAwardTimes() || awardUserDo.getEnableAwardTimes() < 1){
            return BaseResult.buildFaild("您当前抽奖机会是"+awardUserDo.getEnableAwardTimes()+"次，分享一次可额外获得1次抽奖机会！");
        }

        //读取设置的中奖规则
        BaseResult loadConfigResult = loadAwardConfig();
        if (!loadConfigResult.isSuccess()) {
            return loadConfigResult;
        }

        //扣除一次抽奖机会
        awardUserDo.setEnableAwardTimes(awardUserDo.getEnableAwardTimes() - 1);
        int num = awardUserDoMapper.updateByPrimaryKeySelective(awardUserDo);
        if(num == 0){
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return BaseResult.buildFaild("扣除抽奖次数失败！");
        }

        //记录抽奖操作
        OpLogDo opLogDo = new OpLogDo();
        opLogDo.setCreateTime(new Date());
        opLogDo.setDelFlag(0);
        opLogDo.setOpenId(baseVo.getOpenId());
        opLogDo.setOpType(OpTypeEnum.AWARD.getKey());
        num = opLogDoMapper.insertSelective(opLogDo);
        if(num == 0){
            //确保原子性操作，不成就回滚
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return BaseResult.buildFaild("设置操作日志失败！");
        }

        //检查是否中过奖，中过奖直接返回您未中奖
        AwardConfigDo resultAward = CommonConstance.AWARD_CONFIG_DO_MAP.get(CommonConstance.AWARD_CONFIG_NO_KEY);
        if(StringUtils.isEmpty(awardUserDo.getAward())){
            //默认第一个是不中奖
            return BaseResult.buildSuccess(resultAward);
        }

        //按照中奖规则，随机抽奖程序
        int seed = (int)(Math.random()*100);
        for(Integer rate:CommonConstance.AWARD_CONFIG_KV_MAP.keySet()){
            if(rate<=seed){
                continue;
            }else{
                resultAward = CommonConstance.AWARD_CONFIG_DO_MAP.get(CommonConstance.AWARD_CONFIG_KV_MAP.get(rate));
            }
        }

        //如果中奖 记录中奖数据
        if(resultAward.getAwarded() == 1){
            awardUserDo.setAward(resultAward.getAward());
            awardUserDo.setAwardLevel(resultAward.getAwardLevel());
            awardUserDo.setAwardTime(new Date());
            num = awardUserDoMapper.updateByPrimaryKeySelective(awardUserDo);
            if(num == 0){
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                return BaseResult.buildFaild("更新抽奖信息失败！");
            }
        }

        //返回抽奖结果
        return BaseResult.buildSuccess(resultAward);
    }

    /**
     * 加载抽奖规则
     * @return
     */
    @Override
    public BaseResult loadAwardConfig() {
        if(!CollectionUtils.isEmpty(CommonConstance.AWARD_CONFIG_DO_MAP)){
            return BaseResult.buildSuccess(true);
        }

        AwardConfigDoExample example = new AwardConfigDoExample();
        AwardConfigDoExample.Criteria criteria = example.createCriteria();
        criteria.andDelFlagEqualTo(0);
        List<AwardConfigDo> awardConfigDos = awardConfigDoMapper.selectByExample(example);
        if(CollectionUtils.isEmpty(awardConfigDos)){
            return BaseResult.buildFaild("抽奖规则未设置，请联系管理员维护！");
        }

        int end = 0;
        for(AwardConfigDo awardConfigDo:awardConfigDos){
            //此处还不完善，应该添加是否中奖标记的
            CommonConstance.AWARD_CONFIG_DO_MAP.put(awardConfigDo.getAwardKey(),awardConfigDo);

            //设定每个抽奖项的下线
            end+=(int)(awardConfigDo.getAwardRate()*100);
            CommonConstance.AWARD_CONFIG_KV_MAP.put(end,awardConfigDo.getAwardKey());

            if(awardConfigDo.getAwarded() == 0){
                CommonConstance.AWARD_CONFIG_NO_KEY = awardConfigDo.getAwardKey();
            }
        }
        return BaseResult.buildSuccess(true);
    }

    @Override
    public BaseResult addAwardInfo(AddAwardInfoInDto inDto) {
        //按照openId查找用户记录
        AwardUserDo awardUserDo = queryUserByOpenId(inDto.getOpenId());

        //用户不存在，添加一条
        //填写必要参数
        if(null == awardUserDo){
            awardUserDo = new AwardUserDo();
            awardUserDo.setOpenId(inDto.getOpenId());
            awardUserDo.setEnableAwardTimes(1);
            awardUserDo.setWechatNick(inDto.getWechatNick());
        }

        awardUserDo.setName(inDto.getName());
        awardUserDo.setPhone(inDto.getPhone());
        awardUserDo.setAddress(inDto.getAddress());

        int num = 0;
        if(null == awardUserDo.getId()){
            num = awardUserDoMapper.insertSelective(awardUserDo);
        }else{
            num = awardUserDoMapper.updateByPrimaryKeySelective(awardUserDo);
        }

        if(num == 0){
            return BaseResult.buildFaild("中奖人信息录入失败！");
        }

        return BaseResult.buildSuccess(awardUserDo);
    }

    /**
     * 依据openId查找用户记录
     * @param openId
     * @return
     */
    private AwardUserDo queryUserByOpenId(String openId) {
        AwardUserDoExample example = new AwardUserDoExample();
        Criteria criteria = example.createCriteria();

        criteria.andOpenIdEqualTo(openId);
        List<AwardUserDo> awardUserDoList = awardUserDoMapper.selectByExample(example);
        if(CollectionUtils.isEmpty(awardUserDoList)){
            return null;
        }else{
            return awardUserDoList.get(0);
        }
    }

    @Override
    public BaseResult queryAwardInfo(QueryAwardInDto inDto) {
        //按照openId查找用户记录
        AwardUserDo awardUserDo = queryUserByOpenId(inDto.getOpenId());
        //不存在用户记录创建一条，默认给一次抽奖机会
        if(null == awardUserDo){
            awardUserDo = new AwardUserDo();
            awardUserDo.setOpenId(inDto.getOpenId());
            awardUserDo.setEnableAwardTimes(1);
            awardUserDo.setWechatNick(inDto.getWechatNick());
            int num = awardUserDoMapper.insertSelective(awardUserDo);
            if(num == 0){
                return BaseResult.buildFaild("查询中奖信息失败");
            }
        }

        return BaseResult.buildSuccess(awardUserDo);
    }
}
