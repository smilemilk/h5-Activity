package com.dianli.task.dressing.enumerate;

public enum OpTypeEnum {

    INDEX(1,"INDEX","访问"),SHARE(2,"SHARE","分享"),AWARD(3,"AWARD","抽奖"),CREATE(4,"CREATE","创建图片"),SACN(5,"SACN","扫描二维码");

    private Integer key;

    private String code;

    private String desc;

    OpTypeEnum(Integer key, String code, String desc) {
        this.key = key;
        this.code = code;
        this.desc = desc;
    }

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
