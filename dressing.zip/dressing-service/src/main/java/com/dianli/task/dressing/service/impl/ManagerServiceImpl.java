package com.dianli.task.dressing.service.impl;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import com.dianli.task.dressing.config.CommonConstance;
import com.dianli.task.dressing.dao.bean.AwardUserDo;
import com.dianli.task.dressing.dao.bean.AwardUserDoExample;
import com.dianli.task.dressing.dao.bean.UserSignUpDo;
import com.dianli.task.dressing.dao.bean.UserSignUpDoExample;
import com.dianli.task.dressing.dao.mapper.AwardUserDoMapper;
import com.dianli.task.dressing.dao.mapper.UserSignUpDoMapper;
import com.dianli.task.dressing.domain.base.BaseResult;
import com.dianli.task.dressing.service.ManagerService;
import com.fasterxml.jackson.databind.ser.Serializers.Base;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.ObjectError;

/**
 * @author Task
 */
@Service
public class ManagerServiceImpl implements ManagerService {

    @Resource
    private UserSignUpDoMapper userSignUpDoMapper;

    @Resource
    private AwardUserDoMapper awardUserDoMapper;

    @Override
    public BaseResult exportSignUp(HttpServletResponse response) {
        UserSignUpDoExample example = new UserSignUpDoExample();
        UserSignUpDoExample.Criteria criteria = example.createCriteria();
        criteria.andDelFlagEqualTo(0);
        List<UserSignUpDo> userSignUpDoList = userSignUpDoMapper.selectByExample(example);
        if(CollectionUtils.isEmpty(userSignUpDoList)){
            userSignUpDoList = new ArrayList<>();
        }

        //构建excel,并返回
        HSSFWorkbook wb = buildExcel(CommonConstance.SIGNUP_ROW_TH_CELLS,CommonConstance.SIGNUP_ROW_TD_CELLS,userSignUpDoList);
        try{
            write(response, wb,"用户报名信息表.xls");
        }catch (Exception e){
            return BaseResult.buildFaild(e.getMessage());
        }
        return BaseResult.buildSuccess(wb);
    }

    @Override
    public BaseResult exportAward(HttpServletResponse response) {
        AwardUserDoExample example = new AwardUserDoExample();
        AwardUserDoExample.Criteria criteria = example.createCriteria();
        criteria.andAwardIsNotNull();
        List<AwardUserDo> awardUserDos = awardUserDoMapper.selectByExample(example);

        //构建excel,并返回
        HSSFWorkbook wb = buildExcel(CommonConstance.AWARD_ROW_TH_CELLS,CommonConstance.AWARD_ROW_TD_CELLS,awardUserDos);

        try{
            write(response, wb,"用户中奖信息表.xls");
        }catch (Exception e){
            return BaseResult.buildFaild(e.getMessage());
        }

        return BaseResult.buildSuccess(wb);
    }

    private void write(HttpServletResponse response, HSSFWorkbook wb,String fileName) throws IOException {
        // 清空response
        response.reset();
        // 设置response的Header
        response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName,"UTF-8"));
        response.addHeader("Content-Length", "");
        OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
        response.setContentType("application/octet-stream");
        wb.write(toClient);
        toClient.flush();
        toClient.close();
    }

    /**
     * 构建工作表
     * @return
     */
    public HSSFWorkbook buildExcel(String[] headers,String[] valueKeys,List values){
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("sheet0");

        //表头构建
        HSSFRow row = sheet.createRow(0);
        for(int i=0;i<headers.length;i++){
            HSSFCell cell=row.createCell(i);
            cell.setCellValue(headers[i]);
        }

        //数据构建
        for(int j= 0;j<values.size();j++){
            HSSFRow dataRow = sheet.createRow(j+1);
            for(int i=0;i<headers.length;i++){
                HSSFCell cell=dataRow.createCell(i);

                String key = valueKeys[i];
                Object value = values.get(i);

                cell.setCellValue(getFieldValue(key,value));
            }
        }

        return wb;
    }

    /**
     * 获取字段的值
     *
     * @param fieldName
     * @param object
     * @return
     */
    public static String getFieldValue(String fieldName, Object object) {
        try {
            String firstLetter = fieldName.substring(0, 1).toUpperCase();
            String getter = "get" + firstLetter + fieldName.substring(1);
            Method method = object.getClass().getMethod(getter, new Class[] {});
            return method.invoke(object, new Object[] {}).toString();
        } catch (Exception e) {
            return "";
        }
    }
}
