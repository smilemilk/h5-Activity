package com.dianli.task.dressing.service;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import com.dianli.task.dressing.domain.base.BaseResult;
import com.dianli.task.dressing.domain.base.BaseVo;
import com.dianli.task.dressing.domain.dto.AuthInDto;
import com.mashape.unirest.http.exceptions.UnirestException;

public interface AuthService {

    String index(BaseVo vo);

    BaseResult baseCallback(AuthInDto inDto, HttpServletResponse resp) throws UnirestException, IOException;

    BaseResult infoCallback(AuthInDto inDto) throws UnirestException;
}
