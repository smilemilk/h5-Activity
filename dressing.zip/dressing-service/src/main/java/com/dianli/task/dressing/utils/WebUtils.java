package com.dianli.task.dressing.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.dianli.task.dressing.config.CommonConstance;
import com.dianli.task.dressing.dao.bean.UserDo;

public class WebUtils {

    /**
     * 获取openId
     * @param request
     * @return
     */
    public static String getOpenId(HttpServletRequest request){
        Object openId = request.getSession().getAttribute(CommonConstance.OPEN_ID_SESSION_KEY);
        if(null == openId){
            return null;
        }else{
            return (String)openId;
        }
    }

    /**
     * 获取微信昵称
     * @param request
     * @return
     */
    public static String getWechatNick(HttpServletRequest request){
        Object wechatNick = request.getSession().getAttribute(CommonConstance.WECHART_NICK_SESSION_KEY);
        if(null == wechatNick){
            return null;
        }else{
            return (String)wechatNick;
        }
    }

    public static void saveToSession(HttpServletRequest request, UserDo userDo){
        HttpSession session = request.getSession();
        session.setAttribute(CommonConstance.OPEN_ID_SESSION_KEY,userDo.getOpenId());
        session.setAttribute(CommonConstance.WECHART_NICK_SESSION_KEY,userDo.getNickName());
    }

}
