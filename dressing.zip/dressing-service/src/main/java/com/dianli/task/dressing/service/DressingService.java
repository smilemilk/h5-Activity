package com.dianli.task.dressing.service;

import com.dianli.task.dressing.domain.base.BaseResult;
import com.dianli.task.dressing.domain.base.BaseVo;
import com.dianli.task.dressing.domain.base.DelBaseInDto;
import com.dianli.task.dressing.domain.dto.AddMaterialInDto;
import com.dianli.task.dressing.domain.dto.QueryMaterialInDto;
import com.dianli.task.dressing.domain.dto.SignUpInDto;

public interface DressingService {
    BaseResult signUp(SignUpInDto baseVo);

    BaseResult addMaterial(AddMaterialInDto baseVo);

    BaseResult queryMaterial(QueryMaterialInDto baseVo);

    BaseResult delMaterial(DelBaseInDto baseVo);

    BaseResult opIndex(BaseVo baseVo);

    BaseResult opCreate(BaseVo baseVo);

    BaseResult opScan(BaseVo baseVo);
}
