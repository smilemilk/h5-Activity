package com.dianli.task.dressing.service;

import javax.servlet.http.HttpServletResponse;

import com.dianli.task.dressing.domain.base.BaseResult;

public interface ManagerService {

    BaseResult exportSignUp(HttpServletResponse response);

    BaseResult exportAward(HttpServletResponse response);
}
