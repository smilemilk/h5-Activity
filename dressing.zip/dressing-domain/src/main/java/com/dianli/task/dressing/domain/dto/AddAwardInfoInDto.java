package com.dianli.task.dressing.domain.dto;

import javax.validation.constraints.NotNull;

import com.dianli.task.dressing.domain.base.BaseVo;
import org.hibernate.validator.constraints.Length;

public class AddAwardInfoInDto extends BaseVo {

    @NotNull(message = "姓名不能为空！")
    private String name;

    @NotNull(message = "手机号不能为空！")
    @Length(min = 11,max = 16,message = "手机号码不正确！")
    private String phone;

    @NotNull(message = "地址不能为空！")
    private String address;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
