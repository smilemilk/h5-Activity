package com.dianli.task.dressing.domain.group;

/**
 * Created By zl on 2018/2/7;
 *
 * @author wb-zl357392
 * @date 2018/02/07
 */
public interface AuthRoleGroup {
}
