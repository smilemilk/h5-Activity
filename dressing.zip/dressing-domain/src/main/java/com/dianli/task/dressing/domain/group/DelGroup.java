package com.dianli.task.dressing.domain.group;

/**
 * 参数校验删除组
 * @author Task
 * @date 2018/1/31
 */
public interface DelGroup {
}
