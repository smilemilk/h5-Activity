package com.dianli.task.dressing.domain.dto;

import java.util.List;

import lombok.Data;

/**
 * @author Task
 */
@Data
public class UserInfoInDto {

    private String errcode;

    private String errmsg;

    private String openid;

    private String nickname;

    private Integer sex;

    private String province;

    private String city;

    private String country;

    private String headingimgurl;

    private List<String> privilege;

    private String unionid;
}
