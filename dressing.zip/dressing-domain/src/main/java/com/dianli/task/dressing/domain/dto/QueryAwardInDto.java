package com.dianli.task.dressing.domain.dto;

import com.dianli.task.dressing.domain.base.BaseVo;

public class QueryAwardInDto extends BaseVo {

}
