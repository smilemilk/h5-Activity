package com.dianli.task.dressing.domain.dto;

import javax.validation.constraints.NotNull;

import com.dianli.task.dressing.domain.base.BaseVo;

/**
 * @author Task
 */
public class QueryMaterialInDto extends BaseVo{
    private Integer materialType;

    /**
     * 是否最终选中
     */
    private Integer finalChoice;

    public Integer getFinalChoice() {
        return finalChoice;
    }

    public void setFinalChoice(Integer finalChoice) {
        this.finalChoice = finalChoice;
    }

    public Integer getMaterialType() {
        return materialType;
    }

    public void setMaterialType(Integer materialType) {
        this.materialType = materialType;
    }
}
