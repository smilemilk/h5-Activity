package com.dianli.task.dressing.domain.group;

/**
 *
 * @author Task
 * @date 2018/1/31
 */
public interface ModifyGroup {
}
