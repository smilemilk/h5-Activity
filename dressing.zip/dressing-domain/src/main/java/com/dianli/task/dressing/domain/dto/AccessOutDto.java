package com.dianli.task.dressing.domain.dto;

import lombok.Data;

/**
 * @author Task
 */
@Data
public class AccessOutDto{

    private String errcode;

    private String errmsg;

    private String openid;

    private String access_token;

    private Integer expires_in;

    private String refresh_token;

    private String scope;
}
