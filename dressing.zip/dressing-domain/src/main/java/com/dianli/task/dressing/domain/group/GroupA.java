package com.dianli.task.dressing.domain.group;

/**
 *
 * @author Task
 * @date 2018/2/7
 */
public interface GroupA {
}
