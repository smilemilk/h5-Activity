package com.dianli.task.dressing.domain.group;

/**
 * 参数校验，添加组
 * @author Task
 * @date 2018/1/31
 */
public interface AddGroup {


}

