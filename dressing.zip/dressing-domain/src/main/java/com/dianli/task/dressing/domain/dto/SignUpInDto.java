package com.dianli.task.dressing.domain.dto;

import javax.validation.constraints.NotNull;

import com.dianli.task.dressing.domain.base.BaseVo;
import org.hibernate.validator.constraints.Length;

public class SignUpInDto extends BaseVo {

    @NotNull(message = "姓名不能为空！")
    private String name;

    @NotNull(message = "手机号不能为空！")
    @Length(min = 11,max = 16,message = "手机号不正确！")
    private String phone;

    @NotNull(message = "是否携带儿童不能为空！")
    private Integer carryChildren;

    private Integer childrenAge;

    private Integer turnoutNum;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getCarryChildren() {
        return carryChildren;
    }

    public void setCarryChildren(Integer carryChildren) {
        this.carryChildren = carryChildren;
    }

    public Integer getChildrenAge() {
        return childrenAge;
    }

    public void setChildrenAge(Integer childrenAge) {
        this.childrenAge = childrenAge;
    }

    public Integer getTurnoutNum() {
        return turnoutNum;
    }

    public void setTurnoutNum(Integer turnoutNum) {
        this.turnoutNum = turnoutNum;
    }
}
