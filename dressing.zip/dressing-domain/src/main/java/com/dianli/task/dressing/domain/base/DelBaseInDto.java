package com.dianli.task.dressing.domain.base;

import javax.validation.constraints.NotNull;

public class DelBaseInDto extends BaseVo {

    @NotNull(message = "待删除资源编号不能为空！")
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
