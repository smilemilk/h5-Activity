package com.dianli.task.dressing.domain.base;

import javax.validation.constraints.NotNull;

public class BaseVo {

    @NotNull(message = "openId不能为空！")
    private String openId;

    @NotNull(message = "微信昵称不能为空！")
    private String wechatNick;

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getWechatNick() {
        return wechatNick;
    }

    public void setWechatNick(String wechatNick) {
        this.wechatNick = wechatNick;
    }
}
