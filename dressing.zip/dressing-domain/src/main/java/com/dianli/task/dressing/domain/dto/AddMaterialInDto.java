package com.dianli.task.dressing.domain.dto;

import javax.validation.constraints.NotNull;

import com.dianli.task.dressing.domain.base.BaseVo;

public class AddMaterialInDto extends BaseVo {

    @NotNull(message = "素材类型不能为空！")
    private Integer materialType;

    @NotNull(message = "素材信息不能为空！")
    private String material;

    public Integer getMaterialType() {
        return materialType;
    }

    public void setMaterialType(Integer materialType) {
        this.materialType = materialType;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }
}
