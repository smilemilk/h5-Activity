package com.dianli.task.dressing.dao.mapper;

import com.dianli.task.dressing.dao.bean.AwardRecordDo;
import com.dianli.task.dressing.dao.bean.AwardRecordDoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface AwardRecordDoMapper {
    int countByExample(AwardRecordDoExample example);

    int deleteByExample(AwardRecordDoExample example);

    int deleteByPrimaryKey(Long id);

    int insert(AwardRecordDo record);

    int insertSelective(AwardRecordDo record);

    List<AwardRecordDo> selectByExampleWithRowbounds(AwardRecordDoExample example, RowBounds rowBounds);

    List<AwardRecordDo> selectByExample(AwardRecordDoExample example);

    AwardRecordDo selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") AwardRecordDo record, @Param("example") AwardRecordDoExample example);

    int updateByExample(@Param("record") AwardRecordDo record, @Param("example") AwardRecordDoExample example);

    int updateByPrimaryKeySelective(AwardRecordDo record);

    int updateByPrimaryKey(AwardRecordDo record);
}