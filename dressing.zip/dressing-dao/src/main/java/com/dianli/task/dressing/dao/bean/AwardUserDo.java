package com.dianli.task.dressing.dao.bean;

import java.io.Serializable;
import java.util.Date;

public class AwardUserDo implements Serializable {
    private Long id;

    private String wechatNick;

    private String openId;

    private Integer shareTimes;

    private Integer enableAwardTimes;

    private String award;

    private String awardLevel;

    private Date awardTime;

    private String name;

    private String phone;

    private String address;

    private static final long serialVersionUID = 1L;

    public AwardUserDo(Long id, String wechatNick, String openId, Integer shareTimes, Integer enableAwardTimes, String award, String awardLevel, Date awardTime, String name, String phone, String address) {
        this.id = id;
        this.wechatNick = wechatNick;
        this.openId = openId;
        this.shareTimes = shareTimes;
        this.enableAwardTimes = enableAwardTimes;
        this.award = award;
        this.awardLevel = awardLevel;
        this.awardTime = awardTime;
        this.name = name;
        this.phone = phone;
        this.address = address;
    }

    public AwardUserDo() {
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWechatNick() {
        return wechatNick;
    }

    public void setWechatNick(String wechatNick) {
        this.wechatNick = wechatNick == null ? null : wechatNick.trim();
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId == null ? null : openId.trim();
    }

    public Integer getShareTimes() {
        return shareTimes;
    }

    public void setShareTimes(Integer shareTimes) {
        this.shareTimes = shareTimes;
    }

    public Integer getEnableAwardTimes() {
        return enableAwardTimes;
    }

    public void setEnableAwardTimes(Integer enableAwardTimes) {
        this.enableAwardTimes = enableAwardTimes;
    }

    public String getAward() {
        return award;
    }

    public void setAward(String award) {
        this.award = award == null ? null : award.trim();
    }

    public String getAwardLevel() {
        return awardLevel;
    }

    public void setAwardLevel(String awardLevel) {
        this.awardLevel = awardLevel == null ? null : awardLevel.trim();
    }

    public Date getAwardTime() {
        return awardTime;
    }

    public void setAwardTime(Date awardTime) {
        this.awardTime = awardTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AwardUserDo other = (AwardUserDo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getWechatNick() == null ? other.getWechatNick() == null : this.getWechatNick().equals(other.getWechatNick()))
            && (this.getOpenId() == null ? other.getOpenId() == null : this.getOpenId().equals(other.getOpenId()))
            && (this.getShareTimes() == null ? other.getShareTimes() == null : this.getShareTimes().equals(other.getShareTimes()))
            && (this.getEnableAwardTimes() == null ? other.getEnableAwardTimes() == null : this.getEnableAwardTimes().equals(other.getEnableAwardTimes()))
            && (this.getAward() == null ? other.getAward() == null : this.getAward().equals(other.getAward()))
            && (this.getAwardLevel() == null ? other.getAwardLevel() == null : this.getAwardLevel().equals(other.getAwardLevel()))
            && (this.getAwardTime() == null ? other.getAwardTime() == null : this.getAwardTime().equals(other.getAwardTime()))
            && (this.getName() == null ? other.getName() == null : this.getName().equals(other.getName()))
            && (this.getPhone() == null ? other.getPhone() == null : this.getPhone().equals(other.getPhone()))
            && (this.getAddress() == null ? other.getAddress() == null : this.getAddress().equals(other.getAddress()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getWechatNick() == null) ? 0 : getWechatNick().hashCode());
        result = prime * result + ((getOpenId() == null) ? 0 : getOpenId().hashCode());
        result = prime * result + ((getShareTimes() == null) ? 0 : getShareTimes().hashCode());
        result = prime * result + ((getEnableAwardTimes() == null) ? 0 : getEnableAwardTimes().hashCode());
        result = prime * result + ((getAward() == null) ? 0 : getAward().hashCode());
        result = prime * result + ((getAwardLevel() == null) ? 0 : getAwardLevel().hashCode());
        result = prime * result + ((getAwardTime() == null) ? 0 : getAwardTime().hashCode());
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        result = prime * result + ((getPhone() == null) ? 0 : getPhone().hashCode());
        result = prime * result + ((getAddress() == null) ? 0 : getAddress().hashCode());
        return result;
    }
}