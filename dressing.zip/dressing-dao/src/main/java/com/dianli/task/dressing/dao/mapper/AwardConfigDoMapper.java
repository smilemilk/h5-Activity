package com.dianli.task.dressing.dao.mapper;

import com.dianli.task.dressing.dao.bean.AwardConfigDo;
import com.dianli.task.dressing.dao.bean.AwardConfigDoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface AwardConfigDoMapper {
    int countByExample(AwardConfigDoExample example);

    int deleteByExample(AwardConfigDoExample example);

    int deleteByPrimaryKey(Long id);

    int insert(AwardConfigDo record);

    int insertSelective(AwardConfigDo record);

    List<AwardConfigDo> selectByExampleWithRowbounds(AwardConfigDoExample example, RowBounds rowBounds);

    List<AwardConfigDo> selectByExample(AwardConfigDoExample example);

    AwardConfigDo selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") AwardConfigDo record, @Param("example") AwardConfigDoExample example);

    int updateByExample(@Param("record") AwardConfigDo record, @Param("example") AwardConfigDoExample example);

    int updateByPrimaryKeySelective(AwardConfigDo record);

    int updateByPrimaryKey(AwardConfigDo record);
}