package com.dianli.task.dressing.dao.mapper;

import com.dianli.task.dressing.dao.bean.UserSignUpDo;
import com.dianli.task.dressing.dao.bean.UserSignUpDoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface UserSignUpDoMapper {
    int countByExample(UserSignUpDoExample example);

    int deleteByExample(UserSignUpDoExample example);

    int deleteByPrimaryKey(Long id);

    int insert(UserSignUpDo record);

    int insertSelective(UserSignUpDo record);

    List<UserSignUpDo> selectByExampleWithRowbounds(UserSignUpDoExample example, RowBounds rowBounds);

    List<UserSignUpDo> selectByExample(UserSignUpDoExample example);

    UserSignUpDo selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") UserSignUpDo record, @Param("example") UserSignUpDoExample example);

    int updateByExample(@Param("record") UserSignUpDo record, @Param("example") UserSignUpDoExample example);

    int updateByPrimaryKeySelective(UserSignUpDo record);

    int updateByPrimaryKey(UserSignUpDo record);
}