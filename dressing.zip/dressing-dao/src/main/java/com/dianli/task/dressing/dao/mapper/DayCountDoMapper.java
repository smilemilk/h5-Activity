package com.dianli.task.dressing.dao.mapper;

import com.dianli.task.dressing.dao.bean.DayCountDo;
import com.dianli.task.dressing.dao.bean.DayCountDoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface DayCountDoMapper {
    int countByExample(DayCountDoExample example);

    int deleteByExample(DayCountDoExample example);

    int deleteByPrimaryKey(Long id);

    int insert(DayCountDo record);

    int insertSelective(DayCountDo record);

    List<DayCountDo> selectByExampleWithRowbounds(DayCountDoExample example, RowBounds rowBounds);

    List<DayCountDo> selectByExample(DayCountDoExample example);

    DayCountDo selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") DayCountDo record, @Param("example") DayCountDoExample example);

    int updateByExample(@Param("record") DayCountDo record, @Param("example") DayCountDoExample example);

    int updateByPrimaryKeySelective(DayCountDo record);

    int updateByPrimaryKey(DayCountDo record);
}