package com.dianli.task.dressing.dao.bean;

import java.io.Serializable;

public class AwardConfigDo implements Serializable {
    private Long id;

    private Integer delFlag;

    private Float awardRate;

    private String awardLevel;

    private String award;

    private Integer awardKey;

    private Integer awarded;

    private static final long serialVersionUID = 1L;

    public AwardConfigDo(Long id, Integer delFlag, Float awardRate, String awardLevel, String award, Integer awardKey, Integer awarded) {
        this.id = id;
        this.delFlag = delFlag;
        this.awardRate = awardRate;
        this.awardLevel = awardLevel;
        this.award = award;
        this.awardKey = awardKey;
        this.awarded = awarded;
    }

    public AwardConfigDo() {
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public Float getAwardRate() {
        return awardRate;
    }

    public void setAwardRate(Float awardRate) {
        this.awardRate = awardRate;
    }

    public String getAwardLevel() {
        return awardLevel;
    }

    public void setAwardLevel(String awardLevel) {
        this.awardLevel = awardLevel == null ? null : awardLevel.trim();
    }

    public String getAward() {
        return award;
    }

    public void setAward(String award) {
        this.award = award == null ? null : award.trim();
    }

    public Integer getAwardKey() {
        return awardKey;
    }

    public void setAwardKey(Integer awardKey) {
        this.awardKey = awardKey;
    }

    public Integer getAwarded() {
        return awarded;
    }

    public void setAwarded(Integer awarded) {
        this.awarded = awarded;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AwardConfigDo other = (AwardConfigDo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()))
            && (this.getAwardRate() == null ? other.getAwardRate() == null : this.getAwardRate().equals(other.getAwardRate()))
            && (this.getAwardLevel() == null ? other.getAwardLevel() == null : this.getAwardLevel().equals(other.getAwardLevel()))
            && (this.getAward() == null ? other.getAward() == null : this.getAward().equals(other.getAward()))
            && (this.getAwardKey() == null ? other.getAwardKey() == null : this.getAwardKey().equals(other.getAwardKey()))
            && (this.getAwarded() == null ? other.getAwarded() == null : this.getAwarded().equals(other.getAwarded()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        result = prime * result + ((getAwardRate() == null) ? 0 : getAwardRate().hashCode());
        result = prime * result + ((getAwardLevel() == null) ? 0 : getAwardLevel().hashCode());
        result = prime * result + ((getAward() == null) ? 0 : getAward().hashCode());
        result = prime * result + ((getAwardKey() == null) ? 0 : getAwardKey().hashCode());
        result = prime * result + ((getAwarded() == null) ? 0 : getAwarded().hashCode());
        return result;
    }
}