package com.dianli.task.dressing.dao.mapper;

import com.dianli.task.dressing.dao.bean.MaterialDo;
import com.dianli.task.dressing.dao.bean.MaterialDoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface MaterialDoMapper {
    int countByExample(MaterialDoExample example);

    int deleteByExample(MaterialDoExample example);

    int deleteByPrimaryKey(Long id);

    int insert(MaterialDo record);

    int insertSelective(MaterialDo record);

    List<MaterialDo> selectByExampleWithRowbounds(MaterialDoExample example, RowBounds rowBounds);

    List<MaterialDo> selectByExample(MaterialDoExample example);

    MaterialDo selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") MaterialDo record, @Param("example") MaterialDoExample example);

    int updateByExample(@Param("record") MaterialDo record, @Param("example") MaterialDoExample example);

    int updateByPrimaryKeySelective(MaterialDo record);

    int updateByPrimaryKey(MaterialDo record);
}