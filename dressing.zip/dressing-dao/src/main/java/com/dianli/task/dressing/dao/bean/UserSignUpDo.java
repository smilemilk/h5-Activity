package com.dianli.task.dressing.dao.bean;

import java.io.Serializable;
import java.util.Date;

public class UserSignUpDo implements Serializable {
    private Long id;

    private String openId;

    private String wechatNick;

    private String name;

    private String phone;

    private Integer carryChildren;

    private Integer turnoutNum;

    private Integer childrenAge;

    private Date createTime;

    private Date modifyTime;

    private Integer delFlag;

    private static final long serialVersionUID = 1L;

    public UserSignUpDo(Long id, String openId, String wechatNick, String name, String phone, Integer carryChildren, Integer turnoutNum, Integer childrenAge, Date createTime, Date modifyTime, Integer delFlag) {
        this.id = id;
        this.openId = openId;
        this.wechatNick = wechatNick;
        this.name = name;
        this.phone = phone;
        this.carryChildren = carryChildren;
        this.turnoutNum = turnoutNum;
        this.childrenAge = childrenAge;
        this.createTime = createTime;
        this.modifyTime = modifyTime;
        this.delFlag = delFlag;
    }

    public UserSignUpDo() {
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId == null ? null : openId.trim();
    }

    public String getWechatNick() {
        return wechatNick;
    }

    public void setWechatNick(String wechatNick) {
        this.wechatNick = wechatNick == null ? null : wechatNick.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public Integer getCarryChildren() {
        return carryChildren;
    }

    public void setCarryChildren(Integer carryChildren) {
        this.carryChildren = carryChildren;
    }

    public Integer getTurnoutNum() {
        return turnoutNum;
    }

    public void setTurnoutNum(Integer turnoutNum) {
        this.turnoutNum = turnoutNum;
    }

    public Integer getChildrenAge() {
        return childrenAge;
    }

    public void setChildrenAge(Integer childrenAge) {
        this.childrenAge = childrenAge;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        UserSignUpDo other = (UserSignUpDo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getOpenId() == null ? other.getOpenId() == null : this.getOpenId().equals(other.getOpenId()))
            && (this.getWechatNick() == null ? other.getWechatNick() == null : this.getWechatNick().equals(other.getWechatNick()))
            && (this.getName() == null ? other.getName() == null : this.getName().equals(other.getName()))
            && (this.getPhone() == null ? other.getPhone() == null : this.getPhone().equals(other.getPhone()))
            && (this.getCarryChildren() == null ? other.getCarryChildren() == null : this.getCarryChildren().equals(other.getCarryChildren()))
            && (this.getTurnoutNum() == null ? other.getTurnoutNum() == null : this.getTurnoutNum().equals(other.getTurnoutNum()))
            && (this.getChildrenAge() == null ? other.getChildrenAge() == null : this.getChildrenAge().equals(other.getChildrenAge()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getModifyTime() == null ? other.getModifyTime() == null : this.getModifyTime().equals(other.getModifyTime()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getOpenId() == null) ? 0 : getOpenId().hashCode());
        result = prime * result + ((getWechatNick() == null) ? 0 : getWechatNick().hashCode());
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        result = prime * result + ((getPhone() == null) ? 0 : getPhone().hashCode());
        result = prime * result + ((getCarryChildren() == null) ? 0 : getCarryChildren().hashCode());
        result = prime * result + ((getTurnoutNum() == null) ? 0 : getTurnoutNum().hashCode());
        result = prime * result + ((getChildrenAge() == null) ? 0 : getChildrenAge().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getModifyTime() == null) ? 0 : getModifyTime().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        return result;
    }
}