package com.dianli.task.dressing.dao.bean;

import java.io.Serializable;
import java.util.Date;

public class DayCountDo implements Serializable {
    private Long id;

    private Date createDate;

    private Long pv;

    private Long uv;

    private Long createPhotoTimes;

    private Long shareTimes;

    private Long scanTimes;

    private static final long serialVersionUID = 1L;

    public DayCountDo(Long id, Date createDate, Long pv, Long uv, Long createPhotoTimes, Long shareTimes, Long scanTimes) {
        this.id = id;
        this.createDate = createDate;
        this.pv = pv;
        this.uv = uv;
        this.createPhotoTimes = createPhotoTimes;
        this.shareTimes = shareTimes;
        this.scanTimes = scanTimes;
    }

    public DayCountDo() {
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Long getPv() {
        return pv;
    }

    public void setPv(Long pv) {
        this.pv = pv;
    }

    public Long getUv() {
        return uv;
    }

    public void setUv(Long uv) {
        this.uv = uv;
    }

    public Long getCreatePhotoTimes() {
        return createPhotoTimes;
    }

    public void setCreatePhotoTimes(Long createPhotoTimes) {
        this.createPhotoTimes = createPhotoTimes;
    }

    public Long getShareTimes() {
        return shareTimes;
    }

    public void setShareTimes(Long shareTimes) {
        this.shareTimes = shareTimes;
    }

    public Long getScanTimes() {
        return scanTimes;
    }

    public void setScanTimes(Long scanTimes) {
        this.scanTimes = scanTimes;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        DayCountDo other = (DayCountDo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getCreateDate() == null ? other.getCreateDate() == null : this.getCreateDate().equals(other.getCreateDate()))
            && (this.getPv() == null ? other.getPv() == null : this.getPv().equals(other.getPv()))
            && (this.getUv() == null ? other.getUv() == null : this.getUv().equals(other.getUv()))
            && (this.getCreatePhotoTimes() == null ? other.getCreatePhotoTimes() == null : this.getCreatePhotoTimes().equals(other.getCreatePhotoTimes()))
            && (this.getShareTimes() == null ? other.getShareTimes() == null : this.getShareTimes().equals(other.getShareTimes()))
            && (this.getScanTimes() == null ? other.getScanTimes() == null : this.getScanTimes().equals(other.getScanTimes()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getCreateDate() == null) ? 0 : getCreateDate().hashCode());
        result = prime * result + ((getPv() == null) ? 0 : getPv().hashCode());
        result = prime * result + ((getUv() == null) ? 0 : getUv().hashCode());
        result = prime * result + ((getCreatePhotoTimes() == null) ? 0 : getCreatePhotoTimes().hashCode());
        result = prime * result + ((getShareTimes() == null) ? 0 : getShareTimes().hashCode());
        result = prime * result + ((getScanTimes() == null) ? 0 : getScanTimes().hashCode());
        return result;
    }
}