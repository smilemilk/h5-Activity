package com.dianli.task.dressing.dao.mapper;

import com.dianli.task.dressing.dao.bean.OpLogDo;
import com.dianli.task.dressing.dao.bean.OpLogDoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface OpLogDoMapper {
    int countByExample(OpLogDoExample example);

    int deleteByExample(OpLogDoExample example);

    int deleteByPrimaryKey(Long id);

    int insert(OpLogDo record);

    int insertSelective(OpLogDo record);

    List<OpLogDo> selectByExampleWithRowbounds(OpLogDoExample example, RowBounds rowBounds);

    List<OpLogDo> selectByExample(OpLogDoExample example);

    OpLogDo selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") OpLogDo record, @Param("example") OpLogDoExample example);

    int updateByExample(@Param("record") OpLogDo record, @Param("example") OpLogDoExample example);

    int updateByPrimaryKeySelective(OpLogDo record);

    int updateByPrimaryKey(OpLogDo record);
}