package com.dianli.task.dressing.dao.mapper;

import com.dianli.task.dressing.dao.bean.AwardUserDo;
import com.dianli.task.dressing.dao.bean.AwardUserDoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface AwardUserDoMapper {
    int countByExample(AwardUserDoExample example);

    int deleteByExample(AwardUserDoExample example);

    int deleteByPrimaryKey(Long id);

    int insert(AwardUserDo record);

    int insertSelective(AwardUserDo record);

    List<AwardUserDo> selectByExampleWithRowbounds(AwardUserDoExample example, RowBounds rowBounds);

    List<AwardUserDo> selectByExample(AwardUserDoExample example);

    AwardUserDo selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") AwardUserDo record, @Param("example") AwardUserDoExample example);

    int updateByExample(@Param("record") AwardUserDo record, @Param("example") AwardUserDoExample example);

    int updateByPrimaryKeySelective(AwardUserDo record);

    int updateByPrimaryKey(AwardUserDo record);
}