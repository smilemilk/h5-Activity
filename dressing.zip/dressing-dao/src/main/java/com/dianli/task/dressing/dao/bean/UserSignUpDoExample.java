package com.dianli.task.dressing.dao.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserSignUpDoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public UserSignUpDoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andOpenIdIsNull() {
            addCriterion("open_id is null");
            return (Criteria) this;
        }

        public Criteria andOpenIdIsNotNull() {
            addCriterion("open_id is not null");
            return (Criteria) this;
        }

        public Criteria andOpenIdEqualTo(String value) {
            addCriterion("open_id =", value, "openId");
            return (Criteria) this;
        }

        public Criteria andOpenIdNotEqualTo(String value) {
            addCriterion("open_id <>", value, "openId");
            return (Criteria) this;
        }

        public Criteria andOpenIdGreaterThan(String value) {
            addCriterion("open_id >", value, "openId");
            return (Criteria) this;
        }

        public Criteria andOpenIdGreaterThanOrEqualTo(String value) {
            addCriterion("open_id >=", value, "openId");
            return (Criteria) this;
        }

        public Criteria andOpenIdLessThan(String value) {
            addCriterion("open_id <", value, "openId");
            return (Criteria) this;
        }

        public Criteria andOpenIdLessThanOrEqualTo(String value) {
            addCriterion("open_id <=", value, "openId");
            return (Criteria) this;
        }

        public Criteria andOpenIdLike(String value) {
            addCriterion("open_id like", value, "openId");
            return (Criteria) this;
        }

        public Criteria andOpenIdNotLike(String value) {
            addCriterion("open_id not like", value, "openId");
            return (Criteria) this;
        }

        public Criteria andOpenIdIn(List<String> values) {
            addCriterion("open_id in", values, "openId");
            return (Criteria) this;
        }

        public Criteria andOpenIdNotIn(List<String> values) {
            addCriterion("open_id not in", values, "openId");
            return (Criteria) this;
        }

        public Criteria andOpenIdBetween(String value1, String value2) {
            addCriterion("open_id between", value1, value2, "openId");
            return (Criteria) this;
        }

        public Criteria andOpenIdNotBetween(String value1, String value2) {
            addCriterion("open_id not between", value1, value2, "openId");
            return (Criteria) this;
        }

        public Criteria andWechatNickIsNull() {
            addCriterion("wechat_nick is null");
            return (Criteria) this;
        }

        public Criteria andWechatNickIsNotNull() {
            addCriterion("wechat_nick is not null");
            return (Criteria) this;
        }

        public Criteria andWechatNickEqualTo(String value) {
            addCriterion("wechat_nick =", value, "wechatNick");
            return (Criteria) this;
        }

        public Criteria andWechatNickNotEqualTo(String value) {
            addCriterion("wechat_nick <>", value, "wechatNick");
            return (Criteria) this;
        }

        public Criteria andWechatNickGreaterThan(String value) {
            addCriterion("wechat_nick >", value, "wechatNick");
            return (Criteria) this;
        }

        public Criteria andWechatNickGreaterThanOrEqualTo(String value) {
            addCriterion("wechat_nick >=", value, "wechatNick");
            return (Criteria) this;
        }

        public Criteria andWechatNickLessThan(String value) {
            addCriterion("wechat_nick <", value, "wechatNick");
            return (Criteria) this;
        }

        public Criteria andWechatNickLessThanOrEqualTo(String value) {
            addCriterion("wechat_nick <=", value, "wechatNick");
            return (Criteria) this;
        }

        public Criteria andWechatNickLike(String value) {
            addCriterion("wechat_nick like", value, "wechatNick");
            return (Criteria) this;
        }

        public Criteria andWechatNickNotLike(String value) {
            addCriterion("wechat_nick not like", value, "wechatNick");
            return (Criteria) this;
        }

        public Criteria andWechatNickIn(List<String> values) {
            addCriterion("wechat_nick in", values, "wechatNick");
            return (Criteria) this;
        }

        public Criteria andWechatNickNotIn(List<String> values) {
            addCriterion("wechat_nick not in", values, "wechatNick");
            return (Criteria) this;
        }

        public Criteria andWechatNickBetween(String value1, String value2) {
            addCriterion("wechat_nick between", value1, value2, "wechatNick");
            return (Criteria) this;
        }

        public Criteria andWechatNickNotBetween(String value1, String value2) {
            addCriterion("wechat_nick not between", value1, value2, "wechatNick");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andPhoneIsNull() {
            addCriterion("phone is null");
            return (Criteria) this;
        }

        public Criteria andPhoneIsNotNull() {
            addCriterion("phone is not null");
            return (Criteria) this;
        }

        public Criteria andPhoneEqualTo(String value) {
            addCriterion("phone =", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneNotEqualTo(String value) {
            addCriterion("phone <>", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneGreaterThan(String value) {
            addCriterion("phone >", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("phone >=", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneLessThan(String value) {
            addCriterion("phone <", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneLessThanOrEqualTo(String value) {
            addCriterion("phone <=", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneLike(String value) {
            addCriterion("phone like", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneNotLike(String value) {
            addCriterion("phone not like", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneIn(List<String> values) {
            addCriterion("phone in", values, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneNotIn(List<String> values) {
            addCriterion("phone not in", values, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneBetween(String value1, String value2) {
            addCriterion("phone between", value1, value2, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneNotBetween(String value1, String value2) {
            addCriterion("phone not between", value1, value2, "phone");
            return (Criteria) this;
        }

        public Criteria andCarryChildrenIsNull() {
            addCriterion("carry_children is null");
            return (Criteria) this;
        }

        public Criteria andCarryChildrenIsNotNull() {
            addCriterion("carry_children is not null");
            return (Criteria) this;
        }

        public Criteria andCarryChildrenEqualTo(Integer value) {
            addCriterion("carry_children =", value, "carryChildren");
            return (Criteria) this;
        }

        public Criteria andCarryChildrenNotEqualTo(Integer value) {
            addCriterion("carry_children <>", value, "carryChildren");
            return (Criteria) this;
        }

        public Criteria andCarryChildrenGreaterThan(Integer value) {
            addCriterion("carry_children >", value, "carryChildren");
            return (Criteria) this;
        }

        public Criteria andCarryChildrenGreaterThanOrEqualTo(Integer value) {
            addCriterion("carry_children >=", value, "carryChildren");
            return (Criteria) this;
        }

        public Criteria andCarryChildrenLessThan(Integer value) {
            addCriterion("carry_children <", value, "carryChildren");
            return (Criteria) this;
        }

        public Criteria andCarryChildrenLessThanOrEqualTo(Integer value) {
            addCriterion("carry_children <=", value, "carryChildren");
            return (Criteria) this;
        }

        public Criteria andCarryChildrenIn(List<Integer> values) {
            addCriterion("carry_children in", values, "carryChildren");
            return (Criteria) this;
        }

        public Criteria andCarryChildrenNotIn(List<Integer> values) {
            addCriterion("carry_children not in", values, "carryChildren");
            return (Criteria) this;
        }

        public Criteria andCarryChildrenBetween(Integer value1, Integer value2) {
            addCriterion("carry_children between", value1, value2, "carryChildren");
            return (Criteria) this;
        }

        public Criteria andCarryChildrenNotBetween(Integer value1, Integer value2) {
            addCriterion("carry_children not between", value1, value2, "carryChildren");
            return (Criteria) this;
        }

        public Criteria andTurnoutNumIsNull() {
            addCriterion("turnout_num is null");
            return (Criteria) this;
        }

        public Criteria andTurnoutNumIsNotNull() {
            addCriterion("turnout_num is not null");
            return (Criteria) this;
        }

        public Criteria andTurnoutNumEqualTo(Integer value) {
            addCriterion("turnout_num =", value, "turnoutNum");
            return (Criteria) this;
        }

        public Criteria andTurnoutNumNotEqualTo(Integer value) {
            addCriterion("turnout_num <>", value, "turnoutNum");
            return (Criteria) this;
        }

        public Criteria andTurnoutNumGreaterThan(Integer value) {
            addCriterion("turnout_num >", value, "turnoutNum");
            return (Criteria) this;
        }

        public Criteria andTurnoutNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("turnout_num >=", value, "turnoutNum");
            return (Criteria) this;
        }

        public Criteria andTurnoutNumLessThan(Integer value) {
            addCriterion("turnout_num <", value, "turnoutNum");
            return (Criteria) this;
        }

        public Criteria andTurnoutNumLessThanOrEqualTo(Integer value) {
            addCriterion("turnout_num <=", value, "turnoutNum");
            return (Criteria) this;
        }

        public Criteria andTurnoutNumIn(List<Integer> values) {
            addCriterion("turnout_num in", values, "turnoutNum");
            return (Criteria) this;
        }

        public Criteria andTurnoutNumNotIn(List<Integer> values) {
            addCriterion("turnout_num not in", values, "turnoutNum");
            return (Criteria) this;
        }

        public Criteria andTurnoutNumBetween(Integer value1, Integer value2) {
            addCriterion("turnout_num between", value1, value2, "turnoutNum");
            return (Criteria) this;
        }

        public Criteria andTurnoutNumNotBetween(Integer value1, Integer value2) {
            addCriterion("turnout_num not between", value1, value2, "turnoutNum");
            return (Criteria) this;
        }

        public Criteria andChildrenAgeIsNull() {
            addCriterion("children_age is null");
            return (Criteria) this;
        }

        public Criteria andChildrenAgeIsNotNull() {
            addCriterion("children_age is not null");
            return (Criteria) this;
        }

        public Criteria andChildrenAgeEqualTo(Integer value) {
            addCriterion("children_age =", value, "childrenAge");
            return (Criteria) this;
        }

        public Criteria andChildrenAgeNotEqualTo(Integer value) {
            addCriterion("children_age <>", value, "childrenAge");
            return (Criteria) this;
        }

        public Criteria andChildrenAgeGreaterThan(Integer value) {
            addCriterion("children_age >", value, "childrenAge");
            return (Criteria) this;
        }

        public Criteria andChildrenAgeGreaterThanOrEqualTo(Integer value) {
            addCriterion("children_age >=", value, "childrenAge");
            return (Criteria) this;
        }

        public Criteria andChildrenAgeLessThan(Integer value) {
            addCriterion("children_age <", value, "childrenAge");
            return (Criteria) this;
        }

        public Criteria andChildrenAgeLessThanOrEqualTo(Integer value) {
            addCriterion("children_age <=", value, "childrenAge");
            return (Criteria) this;
        }

        public Criteria andChildrenAgeIn(List<Integer> values) {
            addCriterion("children_age in", values, "childrenAge");
            return (Criteria) this;
        }

        public Criteria andChildrenAgeNotIn(List<Integer> values) {
            addCriterion("children_age not in", values, "childrenAge");
            return (Criteria) this;
        }

        public Criteria andChildrenAgeBetween(Integer value1, Integer value2) {
            addCriterion("children_age between", value1, value2, "childrenAge");
            return (Criteria) this;
        }

        public Criteria andChildrenAgeNotBetween(Integer value1, Integer value2) {
            addCriterion("children_age not between", value1, value2, "childrenAge");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeIsNull() {
            addCriterion("modify_time is null");
            return (Criteria) this;
        }

        public Criteria andModifyTimeIsNotNull() {
            addCriterion("modify_time is not null");
            return (Criteria) this;
        }

        public Criteria andModifyTimeEqualTo(Date value) {
            addCriterion("modify_time =", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeNotEqualTo(Date value) {
            addCriterion("modify_time <>", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeGreaterThan(Date value) {
            addCriterion("modify_time >", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("modify_time >=", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeLessThan(Date value) {
            addCriterion("modify_time <", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeLessThanOrEqualTo(Date value) {
            addCriterion("modify_time <=", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeIn(List<Date> values) {
            addCriterion("modify_time in", values, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeNotIn(List<Date> values) {
            addCriterion("modify_time not in", values, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeBetween(Date value1, Date value2) {
            addCriterion("modify_time between", value1, value2, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeNotBetween(Date value1, Date value2) {
            addCriterion("modify_time not between", value1, value2, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNull() {
            addCriterion("del_flag is null");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNotNull() {
            addCriterion("del_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDelFlagEqualTo(Integer value) {
            addCriterion("del_flag =", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotEqualTo(Integer value) {
            addCriterion("del_flag <>", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThan(Integer value) {
            addCriterion("del_flag >", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThanOrEqualTo(Integer value) {
            addCriterion("del_flag >=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThan(Integer value) {
            addCriterion("del_flag <", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThanOrEqualTo(Integer value) {
            addCriterion("del_flag <=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagIn(List<Integer> values) {
            addCriterion("del_flag in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotIn(List<Integer> values) {
            addCriterion("del_flag not in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagBetween(Integer value1, Integer value2) {
            addCriterion("del_flag between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotBetween(Integer value1, Integer value2) {
            addCriterion("del_flag not between", value1, value2, "delFlag");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}