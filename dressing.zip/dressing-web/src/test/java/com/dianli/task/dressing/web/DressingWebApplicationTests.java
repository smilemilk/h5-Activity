package com.dianli.task.dressing.web;

import com.dianli.task.dressing.dao.bean.AwardConfigDo;
import com.dianli.task.dressing.dao.mapper.AwardConfigDoMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DressingWebApplicationTests {

	@Autowired
	private AwardConfigDoMapper awardConfigDoMapper;

	@Test
	public void contextLoads() {
		awardConfigDoMapper.selectByPrimaryKey(1L);
	}

	@Test
	public void test(){
		AwardConfigDo awardConfigDo = new AwardConfigDo();
		awardConfigDo.setAward("雨伞");
		awardConfigDo.setAwardKey(1);
		awardConfigDo.setAwardLevel("一等奖");
		awardConfigDo.setAwardRate(0.2f);
		awardConfigDo.setDelFlag(0);
		awardConfigDoMapper.insertSelective(awardConfigDo);
	}

}
