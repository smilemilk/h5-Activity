/*
SQLyog Ultimate v12.4.1 (64 bit)
MySQL - 5.0.22-community-nt : Database - dressing
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dressing` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;

USE `dressing`;

/*Table structure for table `award_config` */

DROP TABLE IF EXISTS `award_config`;

CREATE TABLE `award_config` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `del_flag` int(1) NOT NULL default '0',
  `award_rate` float NOT NULL COMMENT '中奖概率 0.1,1,2等',
  `award_level` varchar(30) collate utf8_bin NOT NULL COMMENT '奖品等级 一等奖等',
  `award` varchar(128) collate utf8_bin default NULL COMMENT '奖品',
  `award_key` int(1) default NULL COMMENT '奖项标志，便于和前台同步，单次设定不应该重复',
  `awarded` int(1) NOT NULL default '0' COMMENT '区别中奖和不中奖的标记 0：没有中奖 1：中奖',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `award_config` */

insert  into `award_config`(`id`,`del_flag`,`award_rate`,`award_level`,`award`,`award_key`,`awarded`) values 
(1,0,0.2,'一等奖','雨伞',1,0);

/*Table structure for table `award_record` */

DROP TABLE IF EXISTS `award_record`;

CREATE TABLE `award_record` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `open_id` varchar(64) collate utf8_bin NOT NULL,
  `create_time` datetime default NULL,
  `modify_time` datetime default NULL,
  `del_flag` int(1) NOT NULL default '0',
  `award_key` int(1) NOT NULL COMMENT '中奖关键字',
  `award_id` bigint(20) default NULL COMMENT '奖项ID',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `award_record` */

/*Table structure for table `award_user` */

DROP TABLE IF EXISTS `award_user`;

CREATE TABLE `award_user` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `wechat_nick` varchar(128) collate utf8_bin default NULL COMMENT '微信昵称',
  `open_id` varchar(64) collate utf8_bin NOT NULL,
  `enable_award_times` int(1) default NULL COMMENT '可抽奖次数',
  `award` varchar(64) collate utf8_bin default NULL COMMENT '奖品',
  `award_level` varchar(64) collate utf8_bin default NULL COMMENT '中奖等级',
  `award_time` datetime default NULL COMMENT '中奖时间',
  `name` varchar(128) collate utf8_bin default NULL COMMENT '中奖人姓名',
  `phone` varchar(16) collate utf8_bin default NULL COMMENT '中奖人手机号',
  `address` varchar(256) collate utf8_bin default NULL COMMENT '领奖人地址',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `award_user` */

/*Table structure for table `day_count` */

DROP TABLE IF EXISTS `day_count`;

CREATE TABLE `day_count` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `create_date` datetime NOT NULL,
  `PV` bigint(20) default NULL COMMENT '页面访问量',
  `UV` bigint(20) default NULL COMMENT '独立用户数',
  `create_photo_times` bigint(20) default NULL COMMENT '照片生成次数',
  `share_times` bigint(20) default NULL COMMENT '分享次数',
  `scan_times` bigint(20) default NULL COMMENT '二维码扫描次数',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `day_count` */

/*Table structure for table `material` */

DROP TABLE IF EXISTS `material`;

CREATE TABLE `material` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `open_id` varchar(64) collate utf8_bin NOT NULL,
  `material_type` int(1) default '0',
  `material` varchar(128) collate utf8_bin default NULL,
  `del_flag` int(1) NOT NULL default '0',
  `final_choice` int(1) default '0',
  `create_time` datetime default NULL,
  `modify_time` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `material` */

/*Table structure for table `op_log` */

DROP TABLE IF EXISTS `op_log`;

CREATE TABLE `op_log` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `del_flag` int(1) NOT NULL default '0',
  `open_id` varchar(64) collate utf8_bin NOT NULL COMMENT '用户唯一标志',
  `op_type` int(1) NOT NULL COMMENT '操作类型 1：访问 2：分享 3：抽奖 4：生成照片 5：二维码扫描',
  `op_content` text collate utf8_bin COMMENT '操作内容',
  `create_time` datetime default NULL,
  `modify_time` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `op_log` */

insert  into `op_log`(`id`,`del_flag`,`open_id`,`op_type`,`op_content`,`create_time`,`modify_time`) values 
(1,0,'okqx5whq98jiI0CFW0bD7JaHCwII',1,NULL,'2018-05-09 21:22:26',NULL),
(2,0,'okqx5wqsmrWixmCM1XYOLHF35n7k',1,NULL,'2018-05-09 21:33:12',NULL),
(3,0,'okqx5wqsmrWixmCM1XYOLHF35n7k',1,NULL,'2018-05-09 21:36:25',NULL);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `create_time` datetime default NULL,
  `modify_time` datetime default NULL,
  `del_flag` int(1) NOT NULL default '0',
  `open_id` varchar(64) collate utf8_bin NOT NULL,
  `nick_name` varchar(128) collate utf8_bin default NULL,
  `access_token` varchar(128) collate utf8_bin default NULL,
  `expires_in` int(1) default NULL COMMENT 'ak的有效时间，默认两小时',
  `refresh_token` varchar(128) collate utf8_bin default NULL,
  `scope` varchar(128) collate utf8_bin default NULL COMMENT '用户授权的作用域',
  `sex` int(1) default NULL COMMENT '性别 1：男 2：女 0：未知',
  `province` varchar(128) collate utf8_bin default NULL COMMENT '用户个人资料填写的省份',
  `city` varchar(128) collate utf8_bin default NULL COMMENT '用户所在城市',
  `country` varchar(128) collate utf8_bin default NULL COMMENT '用户所在国家',
  `heading_img_url` varchar(128) collate utf8_bin default NULL COMMENT '用户头像',
  `unionid` varchar(64) collate utf8_bin default NULL COMMENT '通用唯一标志',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `user` */

insert  into `user`(`id`,`create_time`,`modify_time`,`del_flag`,`open_id`,`nick_name`,`access_token`,`expires_in`,`refresh_token`,`scope`,`sex`,`province`,`city`,`country`,`heading_img_url`,`unionid`) values 
(3,'2018-05-09 21:36:25',NULL,0,'okqx5wqsmrWixmCM1XYOLHF35n7k','风信子','9_amx7HmIlYnpDDAGW_t9FL5HPhoPJf3NaYIOGLxZKvhTpOLHZ7AueyjKq7SaLECKy7odF8fQmLUV_Z8Jv6UPuPjeZEfNeR1NI8cbxRqjMqqw',7200,'9_sO3ja88SgsaRPHYMxOMOOx11AhccL5cfH6MOX24Br2vpfBoTEPtqse2JddQqNautQhF8qvp9rCx02XhjfRM-GmSjWuy1yr91ORiuAuUj8_U',NULL,0,'','','',NULL,NULL);

/*Table structure for table `user_sign_up` */

DROP TABLE IF EXISTS `user_sign_up`;

CREATE TABLE `user_sign_up` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `open_id` varchar(64) collate utf8_bin NOT NULL,
  `wechat_nick` varchar(128) collate utf8_bin default NULL COMMENT '微信昵称',
  `name` varchar(128) collate utf8_bin default NULL COMMENT '姓名',
  `phone` varchar(16) collate utf8_bin default NULL COMMENT '手机号',
  `carry_children` int(1) default '0' COMMENT '是否携带儿童',
  `turnout_num` int(1) default NULL COMMENT '预计到场人数',
  `children_age` int(1) default NULL COMMENT '儿童年龄',
  `create_time` datetime default NULL,
  `modify_time` datetime default NULL,
  `del_flag` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `user_sign_up` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
