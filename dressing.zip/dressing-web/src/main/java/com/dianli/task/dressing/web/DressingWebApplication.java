package com.dianli.task.dressing.web;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * @author Task
 */
@SpringBootApplication
@MapperScan(basePackages = "com.dianli.task.dressing.dao")
@ServletComponentScan(basePackages = {"com.dianli.task.dressing.web.filter"})
@ComponentScan(basePackages = {"com.dianli.task.dressing.web.controller","com.dianli.task.dressing.service"})
public class DressingWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(DressingWebApplication.class, args);
    }

}
