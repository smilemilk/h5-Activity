package com.dianli.task.dressing.web;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.dianli.task.dressing.domain.base.BaseResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 通用拦截器，处理接口异常
 * @author Task
 * @date 2018/1/31
 */
@ControllerAdvice
public class ExceptionControllerAdvice {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionControllerAdvice.class);


    /**
     * 统一接口异常处理，输出日志，返回前端原因
     * @param e
     * @return
     */
    @ResponseBody
    @ExceptionHandler(value = Exception.class)
    public BaseResult exceptionHandler(Exception e){
        LOGGER.error("接口异常：",e);

        if(e instanceof BindException){
            BindException exs = (BindException) e;

            List<ObjectError> errors = exs.getAllErrors();
            StringBuffer sb = new StringBuffer();
            for (ObjectError item : errors) {
                sb.append(item.getDefaultMessage());
            }
            return BaseResult.buildFaild(sb.toString());
        }

        return BaseResult.buildFaild(null == e.getMessage()?"系统异常，请联系管理员":e.getMessage());
    }

}
