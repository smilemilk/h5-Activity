package com.dianli.task.dressing.web.filter;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dianli.task.dressing.config.CommonConstance;
import com.dianli.task.dressing.domain.base.BaseVo;
import com.dianli.task.dressing.service.AuthService;
import com.dianli.task.dressing.utils.WebUtils;
import com.dianli.task.dressing.web.ParamterRequestWrapper;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

/**
 * 用于前置填充openId，微信号等数据
 * @author Task
 */
@WebFilter(filterName = "loginFilter",urlPatterns = {"/award/*","/dressing/*","/index","/"},initParams = {})
public class FillBaseVoFilter implements Filter {

    @Resource
    private AuthService authService;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest rq, ServletResponse response, FilterChain chain)
        throws IOException, ServletException {
        ParamterRequestWrapper request = new ParamterRequestWrapper((HttpServletRequest)rq);

        //发现session里面不存在需要的数据，则进入登录逻辑
        String openId = WebUtils.getOpenId(request);
        if(StringUtils.isEmpty(openId)){
            String url = authService.index(new BaseVo());
            ((HttpServletResponse)response).sendRedirect(url);
        }else{
            request.setParameter("openId", openId);
            request.setParameter("wechatNick",WebUtils.getWechatNick(request));
            chain.doFilter(request,response);
        }
    }

    @Override
    public void destroy() {

    }
}
