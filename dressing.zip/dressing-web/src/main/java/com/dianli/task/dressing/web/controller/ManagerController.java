package com.dianli.task.dressing.web.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dianli.task.dressing.config.CommonConstance;
import com.dianli.task.dressing.domain.base.BaseResult;
import com.dianli.task.dressing.service.AwardService;
import com.dianli.task.dressing.service.ManagerService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author Task
 */
@Controller
@RequestMapping("manager")
public class ManagerController {

    @Resource
    private ManagerService managerService;

    @Resource
    private AwardService awardService;

    /**
     * 导出报名信息
     * @return
     */
    @RequestMapping("export/signUp")
    public BaseResult exportSignUp(HttpServletResponse response){
        return managerService.exportSignUp(response);
    }

    /**
     * 导出中奖信息
     * @return
     */
    @RequestMapping("export/award")
    public BaseResult exportAward(HttpServletResponse response){
        return managerService.exportAward(response);
    }

    /**
     * 刷新抽奖设置
     * @return
     */
    @RequestMapping("refresh")
    public BaseResult refreshAwardConfig(){
        CommonConstance.AWARD_CONFIG_DO_MAP.clear();
        CommonConstance.AWARD_CONFIG_KV_MAP.clear();
        CommonConstance.AWARD_CONFIG_NO_KEY = null;
        return awardService.loadAwardConfig();
    }




}
