package com.dianli.task.dressing.web.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import com.dianli.task.dressing.domain.base.BaseResult;
import com.dianli.task.dressing.domain.base.BaseVo;
import com.dianli.task.dressing.domain.dto.AddAwardInfoInDto;
import com.dianli.task.dressing.domain.dto.QueryAwardInDto;
import com.dianli.task.dressing.service.AwardService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author Task
 */
@Controller
@RequestMapping("award")
public class AwardController{

    private static final Logger LOGGER = LoggerFactory.getLogger(AwardController.class);

    @Resource
    private AwardService awardService;

    /**
     * 获取抽奖次数
     * @return
     */
    @RequestMapping("queryAwardTimes")
    @ResponseBody
    public BaseResult queryAwardTimes(@Valid BaseVo baseVo){
        return awardService.queryAwardTimes(baseVo);
    }

    /**
     * 操作分享
     * @return
     */
    @RequestMapping("opShare")
    @ResponseBody
    public BaseResult opShare(@Valid BaseVo baseVo){
        return awardService.opShare(baseVo);
    }

    /**
     * 操作抽奖
     * @return
     */
    @RequestMapping("opAward")
    @ResponseBody
    public BaseResult opAward(@Valid BaseVo inDto){
        return awardService.opAward(inDto);
    }

    /**
     * 录入中奖信息
     * @return
     */
    @RequestMapping("addAwardInfo")
    @ResponseBody
    public BaseResult addAwardInfo(@Valid AddAwardInfoInDto infoInDto){
        return awardService.addAwardInfo(infoInDto);
    }

    /**
     * 录入中奖信息
     * @return
     */
    @RequestMapping("queryAwardInfo")
    @ResponseBody
    public BaseResult queryAwardInfo(@Valid QueryAwardInDto inDto){
        return awardService.queryAwardInfo(inDto);
    }


}
