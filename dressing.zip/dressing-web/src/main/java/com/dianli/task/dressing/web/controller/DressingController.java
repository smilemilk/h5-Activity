package com.dianli.task.dressing.web.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import com.dianli.task.dressing.domain.base.BaseResult;
import com.dianli.task.dressing.domain.base.BaseVo;
import com.dianli.task.dressing.domain.base.DelBaseInDto;
import com.dianli.task.dressing.domain.dto.AddMaterialInDto;
import com.dianli.task.dressing.domain.dto.QueryMaterialInDto;
import com.dianli.task.dressing.domain.dto.SignUpInDto;
import com.dianli.task.dressing.service.AuthService;
import com.dianli.task.dressing.service.DressingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author Task
 */
@Controller
@RequestMapping("dressing")
public class DressingController {

    private static final Logger LOGGER = LoggerFactory.getLogger(DressingController.class);

    @Resource
    private DressingService dressingService;

    @Resource
    private AuthService authService;

    /**
     *  访问首页记录
     * @param inDto
     * @return
     */
    @RequestMapping("opIndex")
    @ResponseBody
    public BaseResult opIndex(@Valid BaseVo inDto){
        return dressingService.opIndex(inDto);
    }

    /**
     * 生成照片
     * @param inDto
     * @return
     */
    @RequestMapping("opCreate")
    @ResponseBody
    public BaseResult opCreate(@Valid BaseVo inDto){
        return dressingService.opCreate(inDto);
    }

    /**
     * 二维码扫描
     * @param inDto
     * @return
     */
    @RequestMapping("opScan")
    @ResponseBody
    public BaseResult opScan(@Valid BaseVo inDto){
        return dressingService.opScan(inDto);
    }

    @RequestMapping("signUp")
    @ResponseBody
    public BaseResult signUp(@Valid SignUpInDto inDto){
        return dressingService.signUp(inDto);
    }

    @RequestMapping("addMaterial")
    @ResponseBody
    public BaseResult addMaterial(@Valid AddMaterialInDto inDto){
        return dressingService.addMaterial(inDto);
    }

    @RequestMapping("queryMaterial")
    @ResponseBody
    public BaseResult queryMaterial(@Valid QueryMaterialInDto inDto){
        return dressingService.queryMaterial(inDto);
    }

    @RequestMapping("delMaterial")
    @ResponseBody
    public BaseResult delMaterial(@Valid DelBaseInDto inDto){
        return dressingService.delMaterial(inDto);
    }
}
