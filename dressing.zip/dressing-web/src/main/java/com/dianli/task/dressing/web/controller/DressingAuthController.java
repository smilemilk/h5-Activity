package com.dianli.task.dressing.web.controller;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dianli.task.dressing.dao.bean.UserDo;
import com.dianli.task.dressing.domain.base.BaseResult;
import com.dianli.task.dressing.domain.base.BaseVo;
import com.dianli.task.dressing.domain.dto.AuthInDto;
import com.dianli.task.dressing.service.AuthService;
import com.dianli.task.dressing.utils.WebUtils;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author Task
 */
@Controller
@RequestMapping("/")
public class DressingAuthController {

    @Resource
    private AuthService authService;

    @RequestMapping("index")
    public void index(HttpServletRequest request, HttpServletResponse response) throws IOException {
        BaseVo baseVo = new BaseVo();
        baseVo.setOpenId(WebUtils.getOpenId(request));
        baseVo.setWechatNick(WebUtils.getWechatNick(request));
        response.sendRedirect(authService.index(baseVo));
    }

    @RequestMapping("baseCallback")
    public void baseCallback(AuthInDto inDto, HttpServletRequest request, HttpServletResponse response)
        throws IOException, UnirestException {
        BaseResult<UserDo> result = authService.baseCallback(inDto,response);
        //成功，获取用户信息，写入缓存
        if(result.isSuccess()){
            WebUtils.saveToSession(request,result.getData());
        }
    }

    @RequestMapping("infoCallback")
    public void infoCallback(AuthInDto inDto,HttpServletRequest request, HttpServletResponse response)
        throws UnirestException {
        BaseResult<UserDo> result = authService.infoCallback(inDto);
        //成功，获取用户信息，写入缓存
        if(result.isSuccess()){
            WebUtils.saveToSession(request,result.getData());
        }
    }
}
